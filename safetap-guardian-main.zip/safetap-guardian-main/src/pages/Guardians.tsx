import { useState } from "react";
import { motion } from "framer-motion";
import { useLanguage } from "@/contexts/LanguageContext";

interface Guardian {
  id: string;
  name: string;
  phone: string;
  relation: string;
}

const Guardians = () => {
  const { t } = useLanguage();
  const [guardians, setGuardians] = useState<Guardian[]>([
    { id: "1", name: "Rahul Kumar", phone: "+91 98765 43210", relation: "Son / बेटा" },
    { id: "2", name: "Priya Sharma", phone: "+91 87654 32109", relation: "Daughter / बेटी" },
  ]);
  const [showForm, setShowForm] = useState(false);
  const [newName, setNewName] = useState("");
  const [newPhone, setNewPhone] = useState("");
  const [newRelation, setNewRelation] = useState("");

  const addGuardian = () => {
    if (newName && newPhone) {
      setGuardians([...guardians, { id: Date.now().toString(), name: newName, phone: newPhone, relation: newRelation }]);
      setNewName(""); setNewPhone(""); setNewRelation("");
      setShowForm(false);
    }
  };

  return (
    <div className="min-h-screen bg-background pb-24">
      <header className="sticky top-0 z-30 bg-guardian text-guardian-foreground px-4 py-4 shadow-lg">
        <div className="max-w-lg mx-auto">
          <h1 className="text-2xl font-extrabold">👨‍👩‍👧 {t("myGuardians")}</h1>
          <p className="text-sm opacity-80">{t("guardiansLinked")}: {guardians.length}</p>
        </div>
      </header>

      <main className="max-w-lg mx-auto px-4 py-6 space-y-4">
        {guardians.map((g, i) => (
          <motion.div
            key={g.id}
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: i * 0.1 }}
            className="rounded-3xl bg-card border-2 border-border p-5 flex items-center gap-4 shadow-sm"
          >
            <div className="w-16 h-16 rounded-full bg-guardian/15 flex items-center justify-center text-3xl">
              👤
            </div>
            <div className="flex-1">
              <p className="text-senior-lg">{g.name}</p>
              <p className="text-lg text-primary font-semibold">{g.phone}</p>
              <p className="text-base text-muted-foreground">{g.relation}</p>
            </div>
            <a href={`tel:${g.phone.replace(/\s/g, "")}`} className="w-14 h-14 rounded-full bg-safe flex items-center justify-center text-2xl active:scale-90 transition-transform">
              📞
            </a>
          </motion.div>
        ))}

        {!showForm ? (
          <button
            onClick={() => setShowForm(true)}
            className="w-full touch-target-lg rounded-3xl border-2 border-dashed border-guardian/40 p-5 text-senior-lg text-guardian font-bold active:scale-95 transition-transform"
          >
            ➕ {t("addGuardian")}
          </button>
        ) : (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="rounded-3xl bg-card border-2 border-guardian/30 p-6 space-y-4 shadow-lg"
          >
            <h3 className="text-senior-lg">{t("addGuardian")}</h3>
            <input
              value={newName}
              onChange={(e) => setNewName(e.target.value)}
              placeholder={t("guardianName")}
              className="w-full touch-target rounded-2xl border-2 border-border bg-background px-4 py-3 text-senior focus:border-guardian focus:outline-none"
            />
            <input
              value={newPhone}
              onChange={(e) => setNewPhone(e.target.value)}
              placeholder={t("guardianPhone")}
              type="tel"
              className="w-full touch-target rounded-2xl border-2 border-border bg-background px-4 py-3 text-senior focus:border-guardian focus:outline-none"
            />
            <input
              value={newRelation}
              onChange={(e) => setNewRelation(e.target.value)}
              placeholder={t("guardianRelation")}
              className="w-full touch-target rounded-2xl border-2 border-border bg-background px-4 py-3 text-senior focus:border-guardian focus:outline-none"
            />
            <div className="flex gap-3">
              <button onClick={addGuardian} className="flex-1 touch-target-lg rounded-2xl bg-guardian text-guardian-foreground text-senior-lg py-4 font-bold active:scale-95 transition-transform">
                {t("save")}
              </button>
              <button onClick={() => setShowForm(false)} className="flex-1 touch-target-lg rounded-2xl bg-muted text-muted-foreground text-senior-lg py-4 font-bold active:scale-95 transition-transform">
                {t("cancel")}
              </button>
            </div>
          </motion.div>
        )}
      </main>
    </div>
  );
};

export default Guardians;
