import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useLanguage } from "@/contexts/LanguageContext";
import { Phone, Mail, ArrowRight, Shield, User } from "lucide-react";

type LoginStep = "method" | "otp" | "profile";
type LoginMethod = "phone" | "email";

const Login = ({ onComplete }: { onComplete: () => void }) => {
  const { t } = useLanguage();
  const [step, setStep] = useState<LoginStep>("method");
  const [method, setMethod] = useState<LoginMethod>("phone");
  const [value, setValue] = useState("");
  const [otp, setOtp] = useState("");
  const [profile, setProfile] = useState({
    firstName: "",
    lastName: "",
    dob: "",
    bankAccount: "",
    ifscCode: "",
  });

  const handleSendOtp = () => {
    if (value.length >= 5) setStep("otp");
  };

  const handleVerifyOtp = () => {
    if (otp.length >= 4) setStep("profile");
  };

  const handleSaveProfile = () => {
    if (profile.firstName && profile.lastName) {
      localStorage.setItem("safetap-user", JSON.stringify({ method, value, ...profile }));
      onComplete();
    }
  };

  const slideVariants = {
    enter: { x: 50, opacity: 0 },
    center: { x: 0, opacity: 1 },
    exit: { x: -50, opacity: 0 },
  };

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* Hero Header */}
      <div className="bg-primary text-primary-foreground px-6 pt-12 pb-10 text-center">
        <motion.div
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ type: "spring", stiffness: 200, damping: 20 }}
        >
          <Shield className="w-16 h-16 mx-auto mb-4 opacity-90" />
          <h1 className="text-3xl font-extrabold tracking-tight">🛡️ SafeTap</h1>
          <p className="text-base opacity-80 mt-2">Your Digital Safety Shield</p>
        </motion.div>
      </div>

      <div className="flex-1 px-5 py-8 max-w-md mx-auto w-full">
        <AnimatePresence mode="wait">
          {/* Step 1: Choose Method */}
          {step === "method" && (
            <motion.div key="method" variants={slideVariants} initial="enter" animate="center" exit="exit" className="space-y-6">
              <h2 className="text-senior-lg text-center">How would you like to login?</h2>

              <div className="grid grid-cols-2 gap-4">
                <button
                  onClick={() => setMethod("phone")}
                  className={`touch-target-lg rounded-2xl border-2 p-5 flex flex-col items-center gap-3 transition-all active:scale-95 ${
                    method === "phone" ? "border-primary bg-primary/10" : "border-border bg-card"
                  }`}
                >
                  <Phone className={`w-10 h-10 ${method === "phone" ? "text-primary" : "text-muted-foreground"}`} />
                  <span className="text-senior font-bold">Mobile</span>
                </button>
                <button
                  onClick={() => setMethod("email")}
                  className={`touch-target-lg rounded-2xl border-2 p-5 flex flex-col items-center gap-3 transition-all active:scale-95 ${
                    method === "email" ? "border-primary bg-primary/10" : "border-border bg-card"
                  }`}
                >
                  <Mail className={`w-10 h-10 ${method === "email" ? "text-primary" : "text-muted-foreground"}`} />
                  <span className="text-senior font-bold">Email</span>
                </button>
              </div>

              <div className="space-y-3">
                <label className="text-base font-semibold text-muted-foreground">
                  {method === "phone" ? "Enter Mobile Number" : "Enter Email Address"}
                </label>
                <input
                  type={method === "phone" ? "tel" : "email"}
                  value={value}
                  onChange={(e) => setValue(e.target.value)}
                  placeholder={method === "phone" ? "+91 98765 43210" : "name@example.com"}
                  className="w-full touch-target rounded-2xl border-2 border-border bg-card px-5 py-4 text-senior font-medium focus:border-primary focus:outline-none transition-colors"
                />
              </div>

              <motion.button
                whileTap={{ scale: 0.95 }}
                onClick={handleSendOtp}
                disabled={value.length < 5}
                className="w-full touch-target-lg rounded-2xl bg-primary text-primary-foreground text-senior-lg py-4 font-bold shadow-lg flex items-center justify-center gap-3 disabled:opacity-50 transition-all"
              >
                Send OTP <ArrowRight className="w-6 h-6" />
              </motion.button>
            </motion.div>
          )}

          {/* Step 2: OTP */}
          {step === "otp" && (
            <motion.div key="otp" variants={slideVariants} initial="enter" animate="center" exit="exit" className="space-y-6">
              <h2 className="text-senior-lg text-center">Enter OTP</h2>
              <p className="text-center text-muted-foreground text-base">
                OTP sent to <span className="font-bold text-foreground">{value}</span>
              </p>

              <input
                type="number"
                value={otp}
                onChange={(e) => setOtp(e.target.value.slice(0, 6))}
                placeholder="● ● ● ● ● ●"
                className="w-full touch-target rounded-2xl border-2 border-border bg-card px-5 py-5 text-center text-3xl font-extrabold tracking-[0.5em] focus:border-primary focus:outline-none transition-colors"
                maxLength={6}
              />

              <motion.button
                whileTap={{ scale: 0.95 }}
                onClick={handleVerifyOtp}
                disabled={otp.length < 4}
                className="w-full touch-target-lg rounded-2xl bg-primary text-primary-foreground text-senior-lg py-4 font-bold shadow-lg flex items-center justify-center gap-3 disabled:opacity-50 transition-all"
              >
                Verify <ArrowRight className="w-6 h-6" />
              </motion.button>

              <button onClick={() => setStep("method")} className="w-full text-center text-primary text-base font-semibold">
                ← Change {method === "phone" ? "number" : "email"}
              </button>
            </motion.div>
          )}

          {/* Step 3: Profile */}
          {step === "profile" && (
            <motion.div key="profile" variants={slideVariants} initial="enter" animate="center" exit="exit" className="space-y-5">
              <div className="text-center">
                <User className="w-12 h-12 mx-auto text-primary mb-2" />
                <h2 className="text-senior-lg">Create Your Profile</h2>
                <p className="text-sm text-muted-foreground">This helps us protect you better</p>
              </div>

              {[
                { key: "firstName", label: "First Name", placeholder: "Enter first name", type: "text" },
                { key: "lastName", label: "Last Name", placeholder: "Enter last name", type: "text" },
                { key: "dob", label: "Date of Birth", placeholder: "", type: "date" },
                { key: "bankAccount", label: "Bank Account No. (Optional)", placeholder: "Enter account number", type: "text" },
                { key: "ifscCode", label: "IFSC Code (Optional)", placeholder: "e.g. SBIN0001234", type: "text" },
              ].map((field) => (
                <div key={field.key} className="space-y-1">
                  <label className="text-sm font-semibold text-muted-foreground">{field.label}</label>
                  <input
                    type={field.type}
                    value={profile[field.key as keyof typeof profile]}
                    onChange={(e) => setProfile((p) => ({ ...p, [field.key]: e.target.value }))}
                    placeholder={field.placeholder}
                    className="w-full touch-target rounded-2xl border-2 border-border bg-card px-5 py-3 text-lg font-medium focus:border-primary focus:outline-none transition-colors"
                  />
                </div>
              ))}

              <motion.button
                whileTap={{ scale: 0.95 }}
                onClick={handleSaveProfile}
                disabled={!profile.firstName || !profile.lastName}
                className="w-full touch-target-lg rounded-2xl bg-safe text-safe-foreground text-senior-lg py-4 font-bold shadow-lg flex items-center justify-center gap-3 disabled:opacity-50 transition-all"
              >
                Get Started 🛡️
              </motion.button>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
};

export default Login;
