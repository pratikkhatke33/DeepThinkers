import { motion } from "framer-motion";
import { useLanguage } from "@/contexts/LanguageContext";

const Report = () => {
  const { t } = useLanguage();

  const actions = [
    { label: t("callPolice"), icon: "🔒", href: "tel:1930", color: "bg-danger text-danger-foreground" },
    { label: t("fileComplaint"), icon: "📝", href: "https://cybercrime.gov.in", color: "bg-primary text-primary-foreground" },
    { label: t("alertBank"), icon: "🏦", href: "tel:18001111109", color: "bg-warning text-warning-foreground" },
    { label: t("downloadReport"), icon: "📄", href: "#", color: "bg-safe text-safe-foreground" },
  ];

  return (
    <div className="min-h-screen bg-background pb-24">
      <header className="sticky top-0 z-30 bg-danger text-danger-foreground px-4 py-4 shadow-lg">
        <div className="max-w-lg mx-auto">
          <h1 className="text-2xl font-extrabold">📋 {t("reportTitle")}</h1>
          <p className="text-sm opacity-80">{t("reportDescription")}</p>
        </div>
      </header>

      <main className="max-w-lg mx-auto px-4 py-6 space-y-4">
        {actions.map((action, i) => (
          <motion.a
            key={i}
            href={action.href}
            target={action.href.startsWith("http") ? "_blank" : undefined}
            rel="noopener noreferrer"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1 }}
            className={`touch-target-lg flex items-center gap-4 rounded-3xl ${action.color} p-6 shadow-lg active:scale-[0.98] transition-transform block`}
          >
            <span className="text-5xl">{action.icon}</span>
            <span className="text-senior-lg flex-1">{action.label}</span>
            <span className="text-2xl">→</span>
          </motion.a>
        ))}

        {/* Recent Reports */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="rounded-3xl bg-card border-2 border-border p-6 shadow-sm"
        >
          <h3 className="text-senior-lg mb-4">📊 Recent Scam Reports</h3>
          <div className="space-y-3">
            {[
              { number: "+91 9XXXX-XXXXX", type: "Digital Arrest", time: "2 hours ago", risk: 92 },
              { number: "+91 8XXXX-XXXXX", type: "Bank Fraud", time: "1 day ago", risk: 78 },
            ].map((report, i) => (
              <div key={i} className="rounded-2xl bg-muted p-4">
                <div className="flex justify-between items-center">
                  <div>
                    <p className="text-senior font-semibold">{report.type}</p>
                    <p className="text-base text-muted-foreground">{report.number} · {report.time}</p>
                  </div>
                  <span className="px-3 py-1 rounded-full bg-danger text-danger-foreground text-sm font-bold">
                    Risk: {report.risk}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </motion.div>
      </main>
    </div>
  );
};

export default Report;
