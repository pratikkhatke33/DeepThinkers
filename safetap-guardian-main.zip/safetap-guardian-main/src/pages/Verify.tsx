import { useState } from "react";
import { motion } from "framer-motion";
import { useLanguage } from "@/contexts/LanguageContext";

const Verify = () => {
  const { t } = useLanguage();
  const [revealedAnswers, setRevealedAnswers] = useState<Set<number>>(new Set());

  const questions = [
    { q: t("verifyQuestion1"), a: t("verifyAnswer1"), icon: "🚔" },
    { q: t("verifyQuestion2"), a: t("verifyAnswer2"), icon: "💰" },
    { q: t("verifyQuestion3"), a: t("verifyAnswer3"), icon: "🏛️" },
  ];

  const toggleAnswer = (idx: number) => {
    const next = new Set(revealedAnswers);
    if (next.has(idx)) next.delete(idx); else next.add(idx);
    setRevealedAnswers(next);
  };

  return (
    <div className="min-h-screen bg-background pb-24">
      <header className="sticky top-0 z-30 bg-primary text-primary-foreground px-4 py-4 shadow-lg">
        <div className="max-w-lg mx-auto">
          <h1 className="text-2xl font-extrabold">✅ {t("verifyTitle")}</h1>
          <p className="text-sm opacity-80">{t("verifyDescription")}</p>
        </div>
      </header>

      <main className="max-w-lg mx-auto px-4 py-6 space-y-4">
        {questions.map((item, i) => (
          <motion.div
            key={i}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1 }}
          >
            <button
              onClick={() => toggleAnswer(i)}
              className="w-full text-left rounded-3xl bg-card border-2 border-border p-6 shadow-sm active:scale-[0.98] transition-transform"
            >
              <div className="flex items-start gap-4">
                <span className="text-4xl">{item.icon}</span>
                <p className="text-senior-lg flex-1">{item.q}</p>
              </div>
            </button>
            {revealedAnswers.has(i) && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: "auto" }}
                className="rounded-b-3xl bg-safe/10 border-2 border-t-0 border-safe/30 px-6 py-5 -mt-2"
              >
                <p className="text-senior font-bold text-safe leading-relaxed">{item.a}</p>
              </motion.div>
            )}
          </motion.div>
        ))}

        {/* Number Check */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="rounded-3xl bg-card border-2 border-border p-6 shadow-sm"
        >
          <h3 className="text-senior-lg mb-3">🔍 Check Suspicious Number</h3>
          <input
            type="tel"
            placeholder="Enter phone number..."
            className="w-full touch-target rounded-2xl border-2 border-border bg-background px-4 py-3 text-senior focus:border-primary focus:outline-none mb-3"
          />
          <button className="w-full touch-target-lg rounded-2xl bg-primary text-primary-foreground text-senior-lg py-4 font-bold active:scale-95 transition-transform">
            Check Number
          </button>
        </motion.div>
      </main>
    </div>
  );
};

export default Verify;
