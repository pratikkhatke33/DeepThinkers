import { motion } from "framer-motion";
import { useLanguage } from "@/contexts/LanguageContext";

const Learn = () => {
  const { t } = useLanguage();

  const educationCards = [
    { title: t("educationTitle1"), desc: t("educationDesc1"), icon: "🚫", color: "bg-danger/10 border-danger/30" },
    { title: t("educationTitle2"), desc: t("educationDesc2"), icon: "🏦", color: "bg-warning/10 border-warning/30" },
    { title: t("educationTitle3"), desc: t("educationDesc3"), icon: "📵", color: "bg-primary/10 border-primary/30" },
    { title: t("educationTitle4"), desc: t("educationDesc4"), icon: "☎️", color: "bg-safe/10 border-safe/30" },
  ];

  return (
    <div className="min-h-screen bg-background pb-24">
      <header className="sticky top-0 z-30 bg-safe text-safe-foreground px-4 py-4 shadow-lg">
        <div className="max-w-lg mx-auto">
          <h1 className="text-2xl font-extrabold">📚 {t("knowYourRights")}</h1>
          <p className="text-sm opacity-80">{t("tips")}</p>
        </div>
      </header>

      <main className="max-w-lg mx-auto px-4 py-6 space-y-4">
        {educationCards.map((card, i) => (
          <motion.div
            key={i}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1 }}
            className={`rounded-3xl border-2 p-6 ${card.color}`}
          >
            <div className="text-5xl mb-3">{card.icon}</div>
            <h3 className="text-senior-lg mb-2">{card.title}</h3>
            <p className="text-senior leading-relaxed">{card.desc}</p>
          </motion.div>
        ))}

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="rounded-3xl bg-card border-2 border-border p-6 text-center"
        >
          <span className="text-5xl block mb-3">🎭</span>
          <h3 className="text-senior-lg mb-2">{t("practiceMode")}</h3>
          <p className="text-senior text-muted-foreground mb-4">
            Practice identifying scam calls in a safe environment
          </p>
          <button className="touch-target-lg w-full rounded-2xl bg-primary text-primary-foreground text-senior-lg py-4 font-bold active:scale-95 transition-transform">
            Start Practice →
          </button>
        </motion.div>
      </main>
    </div>
  );
};

export default Learn;
