import { useState, useEffect, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useLanguage } from "@/contexts/LanguageContext";
import LanguageToggle from "@/components/LanguageToggle";
import ThemeToggle from "@/components/ThemeToggle";
import RiskScoreGauge from "@/components/RiskScoreGauge";
import ScamAlertOverlay from "@/components/ScamAlertOverlay";
import RealTimeDetection from "@/components/RealTimeDetection";
import AutoNotifyBanner from "@/components/AutoNotifyBanner";
import { useNavigate } from "react-router-dom";
import { Phone, PhoneOff } from "lucide-react";

const Home = () => {
  const { t } = useLanguage();
  const navigate = useNavigate();
  const [riskScore, setRiskScore] = useState(12);
  const [showScamAlert, setShowScamAlert] = useState(false);
  const [callActive, setCallActive] = useState(false);
  const [autoNotifying, setAutoNotifying] = useState(false);
  const [notifications, setNotifications] = useState([
    { label: "Police (112)", icon: "🚔", done: false },
    { label: "Cybercrime Helpline (1930)", icon: "🔒", done: false },
    { label: "Bank Fraud Dept.", icon: "🏦", done: false },
    { label: "Guardians", icon: "👨‍👩‍👧", done: false },
  ]);

  const handleScamDetected = useCallback((score: number) => {
    setRiskScore(score);
    setShowScamAlert(true);
    // Auto-notify authorities
    setAutoNotifying(true);
    setNotifications((prev) => prev.map((n) => ({ ...n, done: false })));
    // Simulate sequential notifications
    [0, 1, 2, 3].forEach((i) => {
      setTimeout(() => {
        setNotifications((prev) =>
          prev.map((n, idx) => (idx <= i ? { ...n, done: true } : n))
        );
      }, (i + 1) * 1500);
    });
  }, []);

  const handleEndCall = () => {
    setCallActive(false);
    setShowScamAlert(false);
    setRiskScore(12);
    setAutoNotifying(false);
    setNotifications((prev) => prev.map((n) => ({ ...n, done: false })));
  };

  const statusText = riskScore <= 30 ? t("statusSafe") : riskScore <= 60 ? t("statusCaution") : t("statusDanger");
  const statusBg = riskScore <= 30 ? "bg-safe/10 border-safe/30" : riskScore <= 60 ? "bg-warning/10 border-warning/30" : "bg-danger/10 border-danger/30";

  const quickActions = [
    { label: t("verifyCall"), icon: "✅", action: () => navigate("/verify") },
    { label: t("reportScam"), icon: "🚨", action: () => navigate("/report") },
    { label: t("learnMore"), icon: "📚", action: () => navigate("/learn") },
    { label: t("bankProtect"), icon: "🏦", action: () => {} },
  ];

  const containerVariants = {
    hidden: {},
    show: { transition: { staggerChildren: 0.08 } },
  };
  const itemVariants = {
    hidden: { opacity: 0, y: 24 },
    show: { opacity: 1, y: 0, transition: { type: "spring" as const, stiffness: 300, damping: 30 } },
  };

  return (
    <div className="min-h-screen bg-background pb-24">
      <ScamAlertOverlay
        isVisible={showScamAlert}
        onEndCall={handleEndCall}
        onVerify={() => { setShowScamAlert(false); navigate("/verify"); }}
        onDismiss={() => setShowScamAlert(false)}
      />

      {/* Header */}
      <header className="sticky top-0 z-30 bg-primary text-primary-foreground px-4 py-4 shadow-lg">
        <div className="flex items-center justify-between max-w-lg mx-auto">
          <div>
            <h1 className="text-2xl font-extrabold tracking-tight">🛡️ {t("appName")}</h1>
            <p className="text-sm opacity-80">{t("tagline")}</p>
          </div>
          <div className="flex items-center gap-2">
            <LanguageToggle />
            <ThemeToggle />
          </div>
        </div>
      </header>

      <motion.main
        variants={containerVariants}
        initial="hidden"
        animate="show"
        className="max-w-lg mx-auto px-4 py-6 space-y-5"
      >
        {/* Risk Score */}
        <motion.section variants={itemVariants} className={`rounded-3xl border-2 p-6 ${statusBg} transition-colors duration-500`}>
          <h2 className="text-senior-lg text-center mb-4">{t("riskScore")}</h2>
          <RiskScoreGauge score={riskScore} />
          <p className="text-senior text-center mt-4">{statusText}</p>
        </motion.section>

        {/* Start/End Call Simulation */}
        <motion.section variants={itemVariants}>
          {!callActive ? (
            <motion.button
              whileTap={{ scale: 0.95 }}
              onClick={() => setCallActive(true)}
              className="w-full touch-target-lg rounded-3xl bg-card border-2 border-border p-5 flex items-center gap-4 shadow-sm transition-all hover:shadow-md"
            >
              <div className="w-14 h-14 rounded-2xl bg-safe/20 flex items-center justify-center">
                <Phone className="w-7 h-7 text-safe" />
              </div>
              <div className="text-left flex-1">
                <p className="text-senior-lg">🎭 Demo: Simulate Call</p>
                <p className="text-base text-muted-foreground">Tap to start scam detection demo</p>
              </div>
            </motion.button>
          ) : null}
        </motion.section>

        {/* Real-time Detection Panel */}
        <AnimatePresence>
          {callActive && (
            <RealTimeDetection
              isActive={callActive}
              onScamDetected={handleScamDetected}
              onEndCall={handleEndCall}
            />
          )}
        </AnimatePresence>

        {/* Auto Notification Banner */}
        <AutoNotifyBanner isVisible={autoNotifying} notifications={notifications} />

        {/* Quick Actions */}
        <motion.section variants={itemVariants}>
          <h2 className="text-senior-lg mb-4">{t("quickActions")}</h2>
          <div className="grid grid-cols-2 gap-3">
            {quickActions.map((action, i) => (
              <motion.button
                key={action.label}
                whileTap={{ scale: 0.93 }}
                whileHover={{ y: -2 }}
                onClick={action.action}
                className="touch-target-lg rounded-2xl bg-card border-2 border-border p-4 flex flex-col items-center gap-2 shadow-sm transition-shadow hover:shadow-md"
              >
                <span className="text-4xl">{action.icon}</span>
                <span className="text-senior font-semibold text-center">{action.label}</span>
              </motion.button>
            ))}
          </div>
        </motion.section>

        {/* Emergency Contacts */}
        <motion.section
          variants={itemVariants}
          className="rounded-3xl bg-card border-2 border-border p-5 space-y-3 shadow-sm"
        >
          <h2 className="text-senior-lg">{t("emergencyContacts")}</h2>
          {[
            { label: t("cybercrimeLine"), number: "1930", icon: "🔒" },
            { label: t("policeEmergency"), number: "112", icon: "🚔" },
            { label: t("bankFraud"), number: "1800-111-109", icon: "🏦" },
          ].map((contact) => (
            <motion.a
              key={contact.number}
              href={`tel:${contact.number}`}
              whileTap={{ scale: 0.97 }}
              className="touch-target flex items-center gap-4 rounded-2xl bg-muted p-4 transition-all hover:shadow-sm"
            >
              <span className="text-3xl">{contact.icon}</span>
              <div className="flex-1">
                <p className="text-senior font-semibold">{contact.label}</p>
                <p className="text-lg text-primary font-bold">{contact.number}</p>
              </div>
              <span className="text-2xl">📞</span>
            </motion.a>
          ))}
        </motion.section>
      </motion.main>
    </div>
  );
};

export default Home;
