import { motion } from "framer-motion";
import { useLanguage } from "@/contexts/LanguageContext";

interface PanicButtonProps {
  onPress: () => void;
}

const PanicButton = ({ onPress }: PanicButtonProps) => {
  const { t } = useLanguage();

  return (
    <motion.button
      whileTap={{ scale: 0.92 }}
      onClick={onPress}
      className="relative flex flex-col items-center justify-center w-44 h-44 rounded-full bg-panic text-panic-foreground shadow-2xl animate-pulse-danger touch-target-lg mx-auto"
    >
      <span className="text-5xl mb-1">🆘</span>
      <span className="text-lg font-extrabold tracking-wide leading-tight">{t("panicButton")}</span>
      <span className="text-xs mt-1 opacity-80">{t("panicSubtext")}</span>
    </motion.button>
  );
};

export default PanicButton;
