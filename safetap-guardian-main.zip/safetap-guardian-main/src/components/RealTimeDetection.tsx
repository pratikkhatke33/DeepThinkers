import { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useLanguage } from "@/contexts/LanguageContext";
import { Phone, PhoneOff, ShieldAlert, Activity, Clock, AlertTriangle } from "lucide-react";

interface RealTimeDetectionProps {
  isActive: boolean;
  onScamDetected: (score: number) => void;
  onEndCall: () => void;
}

const SCAM_KEYWORDS = [
  "digital arrest", "CBI case", "account freeze", "transfer money",
  "safe account", "don't tell anyone", "stay on call", "warrant",
  "money laundering", "ED notice", "court order",
];

const RealTimeDetection = ({ isActive, onScamDetected, onEndCall }: RealTimeDetectionProps) => {
  const { t } = useLanguage();
  const [callDuration, setCallDuration] = useState(0);
  const [detectedKeywords, setDetectedKeywords] = useState<string[]>([]);
  const [stressLevel, setStressLevel] = useState<"low" | "medium" | "high">("low");
  const [riskScore, setRiskScore] = useState(0);
  const intervalRef = useRef<ReturnType<typeof setInterval>>();
  const simRef = useRef<ReturnType<typeof setInterval>>();

  useEffect(() => {
    if (isActive) {
      setCallDuration(0);
      setDetectedKeywords([]);
      setStressLevel("low");
      setRiskScore(0);

      intervalRef.current = setInterval(() => {
        setCallDuration((d) => d + 1);
      }, 1000);

      // Simulate detection
      simRef.current = setInterval(() => {
        setDetectedKeywords((prev) => {
          const remaining = SCAM_KEYWORDS.filter((k) => !prev.includes(k));
          if (remaining.length === 0) return prev;
          const next = [...prev, remaining[Math.floor(Math.random() * remaining.length)]];
          const newScore = Math.min(100, next.length * 15 + Math.floor(Math.random() * 10));
          setRiskScore(newScore);
          if (newScore >= 70) {
            setStressLevel("high");
            onScamDetected(newScore);
          } else if (newScore >= 40) {
            setStressLevel("medium");
          }
          return next;
        });
      }, 3000);
    } else {
      clearInterval(intervalRef.current);
      clearInterval(simRef.current);
    }

    return () => {
      clearInterval(intervalRef.current);
      clearInterval(simRef.current);
    };
  }, [isActive, onScamDetected]);

  const formatTime = (s: number) => `${Math.floor(s / 60).toString().padStart(2, "0")}:${(s % 60).toString().padStart(2, "0")}`;

  const scoreColor = riskScore <= 30 ? "text-safe" : riskScore <= 60 ? "text-warning" : "text-danger";
  const stressColors = { low: "bg-safe/20 text-safe", medium: "bg-warning/20 text-warning", high: "bg-danger/20 text-danger" };

  if (!isActive) return null;

  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: 30 }}
      className="rounded-3xl border-2 border-border bg-card p-5 space-y-4 shadow-lg"
    >
      {/* Header with live indicator */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <span className="relative flex h-3 w-3">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-danger opacity-75"></span>
            <span className="relative inline-flex rounded-full h-3 w-3 bg-danger"></span>
          </span>
          <span className="text-senior font-bold">{t("callMonitoring")}</span>
        </div>
        <div className="flex items-center gap-2 text-muted-foreground">
          <Clock className="w-4 h-4" />
          <span className="text-lg font-mono font-bold">{formatTime(callDuration)}</span>
        </div>
      </div>

      {/* Risk Score Bar */}
      <div className="space-y-2">
        <div className="flex items-center justify-between">
          <span className="text-base font-semibold text-muted-foreground">{t("riskScore")}</span>
          <span className={`text-2xl font-extrabold ${scoreColor}`}>{riskScore}/100</span>
        </div>
        <div className="w-full h-3 rounded-full bg-muted overflow-hidden">
          <motion.div
            className={`h-full rounded-full ${riskScore <= 30 ? "bg-safe" : riskScore <= 60 ? "bg-warning" : "bg-danger"}`}
            initial={{ width: 0 }}
            animate={{ width: `${riskScore}%` }}
            transition={{ duration: 0.5 }}
          />
        </div>
      </div>

      {/* Detected Keywords */}
      <div className="space-y-2">
        <div className="flex items-center gap-2">
          <ShieldAlert className="w-4 h-4 text-warning" />
          <span className="text-base font-semibold text-muted-foreground">{t("suspiciousKeywords")}</span>
        </div>
        <div className="flex flex-wrap gap-2">
          <AnimatePresence>
            {detectedKeywords.map((kw) => (
              <motion.span
                key={kw}
                initial={{ scale: 0, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                className="px-3 py-1 rounded-full bg-danger/15 text-danger text-sm font-semibold border border-danger/30"
              >
                {kw}
              </motion.span>
            ))}
          </AnimatePresence>
          {detectedKeywords.length === 0 && (
            <span className="text-sm text-muted-foreground italic">{t("notDetected")}</span>
          )}
        </div>
      </div>

      {/* Stress Level */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Activity className="w-4 h-4 text-muted-foreground" />
          <span className="text-base font-semibold text-muted-foreground">{t("stressLevel")}</span>
        </div>
        <span className={`px-3 py-1 rounded-full text-sm font-bold ${stressColors[stressLevel]}`}>
          {t(stressLevel)}
        </span>
      </div>

      {/* End Call Button */}
      <motion.button
        whileTap={{ scale: 0.95 }}
        onClick={onEndCall}
        className="w-full touch-target-lg rounded-2xl bg-danger text-danger-foreground text-senior-lg py-4 font-bold shadow-lg flex items-center justify-center gap-3 transition-transform"
      >
        <PhoneOff className="w-7 h-7" />
        {t("endCall")}
      </motion.button>
    </motion.div>
  );
};

export default RealTimeDetection;
