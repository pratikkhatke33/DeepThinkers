import { motion, AnimatePresence } from "framer-motion";
import { useLanguage } from "@/contexts/LanguageContext";

interface ScamAlertOverlayProps {
  isVisible: boolean;
  onEndCall: () => void;
  onVerify: () => void;
  onDismiss: () => void;
}

const ScamAlertOverlay = ({ isVisible, onEndCall, onVerify, onDismiss }: ScamAlertOverlayProps) => {
  const { t } = useLanguage();

  return (
    <AnimatePresence>
      {isVisible && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-50 flex items-center justify-center bg-danger/95 p-6"
        >
          <motion.div
            initial={{ scale: 0.8, y: 50 }}
            animate={{ scale: 1, y: 0 }}
            exit={{ scale: 0.8, y: 50 }}
            className="w-full max-w-md rounded-3xl bg-card p-8 text-center shadow-2xl"
          >
            <div className="text-7xl mb-4">🚨</div>
            <h2 className="text-senior-xl text-danger mb-4">{t("scamAlertTitle")}</h2>
            <p className="text-senior text-foreground mb-8 leading-relaxed">
              {t("scamAlertMessage")}
            </p>

            <div className="flex flex-col gap-4">
              <button
                onClick={onEndCall}
                className="touch-target-lg w-full rounded-2xl bg-danger text-danger-foreground text-senior-lg py-5 font-bold shadow-lg active:scale-95 transition-transform"
              >
                📵 {t("endCall")}
              </button>
              <button
                onClick={onVerify}
                className="touch-target-lg w-full rounded-2xl bg-primary text-primary-foreground text-senior-lg py-5 font-bold shadow-lg active:scale-95 transition-transform"
              >
                ✅ {t("verifyNow")}
              </button>
              <button
                onClick={onDismiss}
                className="touch-target w-full rounded-2xl bg-muted text-muted-foreground text-senior py-4 font-medium active:scale-95 transition-transform"
              >
                {t("dismiss")}
              </button>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export default ScamAlertOverlay;
