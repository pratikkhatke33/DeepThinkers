import { useLanguage } from "@/contexts/LanguageContext";
import { useLocation, useNavigate } from "react-router-dom";

const navItems = [
  { key: "home" as const, icon: "🏠", path: "/" },
  { key: "guardians" as const, icon: "👨‍👩‍👧", path: "/guardians" },
  { key: "learn" as const, icon: "📚", path: "/learn" },
  { key: "verify" as const, icon: "✅", path: "/verify" },
  { key: "report" as const, icon: "📋", path: "/report" },
];

const BottomNav = () => {
  const { t } = useLanguage();
  const location = useLocation();
  const navigate = useNavigate();

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 bg-card border-t border-border shadow-lg">
      <div className="flex justify-around items-center max-w-lg mx-auto">
        {navItems.map((item) => {
          const isActive = location.pathname === item.path;
          return (
            <button
              key={item.key}
              onClick={() => navigate(item.path)}
              className={`touch-target flex flex-col items-center justify-center py-2 px-3 transition-all ${
                isActive ? "text-primary scale-110" : "text-muted-foreground"
              }`}
            >
              <span className="text-2xl">{item.icon}</span>
              <span className={`text-xs mt-0.5 font-semibold ${isActive ? "text-primary" : ""}`}>
                {t(item.key)}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
};

export default BottomNav;
