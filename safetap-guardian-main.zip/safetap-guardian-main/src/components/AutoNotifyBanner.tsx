import { motion, AnimatePresence } from "framer-motion";
import { useLanguage } from "@/contexts/LanguageContext";
import { CheckCircle2, ShieldCheck } from "lucide-react";

interface AutoNotifyBannerProps {
  isVisible: boolean;
  notifications: { label: string; icon: string; done: boolean }[];
}

const AutoNotifyBanner = ({ isVisible, notifications }: AutoNotifyBannerProps) => {
  const { t } = useLanguage();

  return (
    <AnimatePresence>
      {isVisible && (
        <motion.div
          initial={{ opacity: 0, height: 0 }}
          animate={{ opacity: 1, height: "auto" }}
          exit={{ opacity: 0, height: 0 }}
          className="rounded-2xl border-2 border-safe/40 bg-safe/10 p-4 space-y-3 overflow-hidden"
        >
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-safe" />
            <span className="text-senior font-bold text-safe">Auto-Alerting Authorities</span>
          </div>
          {notifications.map((n, i) => (
            <motion.div
              key={n.label}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: i * 0.5 }}
              className="flex items-center gap-3"
            >
              <span className="text-2xl">{n.icon}</span>
              <span className="text-base font-medium flex-1">{n.label}</span>
              {n.done ? (
                <CheckCircle2 className="w-5 h-5 text-safe" />
              ) : (
                <span className="w-5 h-5 rounded-full border-2 border-muted-foreground border-t-primary animate-spin" />
              )}
            </motion.div>
          ))}
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export default AutoNotifyBanner;
