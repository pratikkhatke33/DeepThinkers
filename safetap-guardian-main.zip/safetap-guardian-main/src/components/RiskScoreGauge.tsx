import { useLanguage } from "@/contexts/LanguageContext";

interface RiskScoreGaugeProps {
  score: number;
}

const RiskScoreGauge = ({ score }: RiskScoreGaugeProps) => {
  const { t } = useLanguage();

  const getStatus = () => {
    if (score <= 30) return { label: t("safe"), color: "bg-safe text-safe-foreground", ring: "ring-safe" };
    if (score <= 60) return { label: t("caution"), color: "bg-warning text-warning-foreground", ring: "ring-warning" };
    return { label: t("danger"), color: "bg-danger text-danger-foreground", ring: "ring-danger" };
  };

  const status = getStatus();
  const circumference = 2 * Math.PI * 45;
  const dashOffset = circumference - (score / 100) * circumference;

  const strokeColor =
    score <= 30 ? "hsl(var(--safe))" : score <= 60 ? "hsl(var(--warning))" : "hsl(var(--danger))";

  return (
    <div className="flex flex-col items-center gap-3">
      <div className="relative w-32 h-32">
        <svg className="w-full h-full -rotate-90" viewBox="0 0 100 100">
          <circle cx="50" cy="50" r="45" stroke="hsl(var(--muted))" strokeWidth="8" fill="none" />
          <circle
            cx="50"
            cy="50"
            r="45"
            stroke={strokeColor}
            strokeWidth="8"
            fill="none"
            strokeLinecap="round"
            strokeDasharray={circumference}
            strokeDashoffset={dashOffset}
            className="transition-all duration-1000 ease-out"
          />
        </svg>
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <span className="text-3xl font-extrabold text-foreground">{score}</span>
          <span className="text-xs text-muted-foreground">/100</span>
        </div>
      </div>
      <span className={`px-4 py-1.5 rounded-full text-senior font-bold ${status.color}`}>
        {status.label}
      </span>
    </div>
  );
};

export default RiskScoreGauge;
