import { useLanguage } from "@/contexts/LanguageContext";
import { Globe } from "lucide-react";

const LanguageToggle = () => {
  const { language, setLanguage } = useLanguage();

  return (
    <button
      onClick={() => setLanguage(language === "en" ? "hi" : "en")}
      className="touch-target flex items-center gap-2 rounded-xl bg-card/80 backdrop-blur-sm px-3 py-2 text-base font-semibold shadow-sm border border-border transition-all active:scale-90"
    >
      <Globe className="w-4 h-4 text-primary" />
      <span className="text-sm font-bold">{language === "en" ? "हिं" : "EN"}</span>
    </button>
  );
};

export default LanguageToggle;
